# .files

![Screenshot of Tari, my Arch Linux setup.](/.archlinux/screenshots/01.jpg?raw=true)

![Screenshot of Tari with Code and the wal color scheme.](/.archlinux/screenshots/code.jpg?raw=true)
