# yt-dl

[yt-dl][yt-dl] is a media downloading program.

## Use Cases

yt-dl can be used to:

- Download video from a given URL
- Stream video to programs like mpv

You should not use yt-dl if:

- You should use yt-dl.

[yt-dl]: https://github.com/rg3/youtube-dl
