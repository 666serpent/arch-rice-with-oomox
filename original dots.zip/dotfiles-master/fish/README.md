# fish

[fish][fish] is the friendly interactive shell.

## Use Cases

fish can be used to:

- Have syntax highlighting in the terminal with 0 configuration
- Have leading autocompletion in the terminal with 0 configuration
- Set abbreviations instead of aliases, making it easy to remember what aliases expand to

You should not use fish if:

- You should use fish.

[fish]: https://github.com/fish-shell/fish-shell
