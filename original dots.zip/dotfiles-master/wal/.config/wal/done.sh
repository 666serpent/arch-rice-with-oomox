#!/bin/sh

if [ -e ~/.config/bspwm/wal.sh ]; then
  ~/.config/bspwm/wal.sh
fi
