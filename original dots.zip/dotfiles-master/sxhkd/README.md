# sxhkd

[sxhkd][sxhkd] is a hotkey daemon for X11.

## Use Cases

sxhkd can be used to:

- Bind any key combination to whatever shell command you want
- Control windows in [bspwm](/bspwm) through `bspc`

You should not use sxhkd if:

- You use a desktop environment that sets keybinds for you

[sxhkd]: https://github.com/baskerville/sxhkd
