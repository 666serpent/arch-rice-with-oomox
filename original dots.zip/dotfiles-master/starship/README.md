# starship

[starship][starship] is a customizable prompt for any shell.

## Use Cases

starship can be used to:

- Have a prompt that shows relevant information in any situation, with 0 configuration

You should not use starship if:

- You should use starship.

[starship]: https://github.com/starship/starship
