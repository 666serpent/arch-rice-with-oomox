# neofetch

[neofetch][neofetch] is the standard information tool.

## Use Cases

neofetch can be used to:

- Display system information in an elegant way, even through a tty

You should not use neofetch if:

- You should use neofetch.

[neofetch]: https://github.com/dylanaraps/neofetch
