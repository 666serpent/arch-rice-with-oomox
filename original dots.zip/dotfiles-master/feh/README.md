# feh

[feh][feh] is an image viewer with no GUI. It can also change the desktop background.

## Use Cases

feh can be used to:

- Quickly view and browse through images without loading a GUI
- Change your desktop background if not using a desktop environment
- Strategically place GUI-less images in your rice screenshots

You should not use feh if:

- You are using a desktop environment with an image viewer

[feh]: https://github.com/derf/feh
