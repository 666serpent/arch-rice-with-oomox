# mpd

[mpd][mpd] is a music player daemon.

## Use Cases

mpd can be used to:

- Manage music independently of which client is being used

You should not use mpd if:

- The music player you use does not rely on mpd

[mpd]: https://github.com/MusicPlayerDaemon/MPD
