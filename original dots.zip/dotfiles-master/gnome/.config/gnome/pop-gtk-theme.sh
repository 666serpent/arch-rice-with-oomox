#!/bin/sh

# Use the light variant of the Pop GTK theme
gsettings set org.gnome.desktop.interface gtk-theme Pop
gsettings set org.gnome.desktop.interface icon-theme Pop
