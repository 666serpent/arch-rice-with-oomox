#!/bin/sh

# Use the dark variant of the Arc GTK theme
gsettings set org.gnome.desktop.interface gtk-theme Arc-Dark-solid
gsettings set org.gnome.desktop.interface icon-theme Papirus-Dark
