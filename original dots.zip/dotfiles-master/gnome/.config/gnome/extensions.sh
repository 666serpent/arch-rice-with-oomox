#!/bin/sh

# Use the Alternate Tab and Launch New Instance extensions
gsettings set org.gnome.shell enabled-extensions "[
  'alternate-tab@gnome-shell-extensions.gcampax.github.com',
  'launch-new-instance@gnome-shell-extensions.gcampax.github.com'
]"
