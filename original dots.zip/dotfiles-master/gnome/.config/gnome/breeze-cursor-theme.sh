#!/bin/sh

# Use Plasma's default cursor theme in GNOME
gsettings set org.gnome.desktop.interface cursor-theme breeze_cursors
