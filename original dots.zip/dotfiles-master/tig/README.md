# tig

[tig][tig] is an ncurses interface for git.

## Use Cases

tig can be used to:

- Browse git repositories easily

You should not use tig if:

- You should use tig.

[tig]: https://github.com/jonas/tig
