# ranger

[ranger][ranger] is a file browser for the terminal with image support.

## Use Cases

ranger can be used to:

- Easily see all filenames in directories as you browse through them
- Show image previews in the terminal (with [kitty](/kitty))
- Use a file browser even through a tty

You should not use ranger if:

- You should use ranger.

[ranger]: https://github.com/ranger/ranger
