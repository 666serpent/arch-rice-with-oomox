# neovim

[neovim][neovim] is a vim fork with modern defaults.

## Use Cases

neovim can be used to:

- Simplify the process of learning vim, since it uses standard defaults

You should not use neovim if:

- You should use neovim.

[neovim]: https://github.com/neovim/neovim
