# xinit

[xinit][xinit] is used to run the X display server with `startx`.

## Use Cases

xinit can be used to:

- Start X from a tty

You should not use xinit if:

- You use a display manager that bypasses the tty

[xinit]: https://wiki.archlinux.org/index.php/Xinit
