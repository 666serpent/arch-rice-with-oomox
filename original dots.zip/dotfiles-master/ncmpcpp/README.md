# ncmpcpp

[ncmpcpp][ncmpcpp] is a music player client for the terminal.

## Use Cases

ncmpcpp can be used to:

- Manage your entire music library from a pretty terminal interface
- Let your music player have a color scheme consistent to your setup
- Add music functionality in your rice screenshot

You should not use ncmpcpp if:

- You use a desktop environment that already has a music player
- You do not want to use mpd

[ncmpcpp]: https://github.com/arybczak/ncmpcpp
