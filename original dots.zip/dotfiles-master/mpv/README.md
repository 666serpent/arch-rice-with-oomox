# mpv

[mpv][mpv] is a media player without a GUI.

## Use Cases

mpv can be used to:

- Play every video format you encounter
- Work behind the scenes for larger GUI programs
- Watch videos with other tiled windows open and without GUI buttons taking up space
- Strategically position GUI-less videos in your rice screenshots

You should not use mpv if:

- You use a desktop environment with a media player

[mpv]: https://github.com/mpv-player/mpv
