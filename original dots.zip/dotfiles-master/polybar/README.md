# polybar

[polybar][polybar] is an information panel for your desktop.

## Use Cases

polybar can be used to:

- Show the current desktop, empty desktops, and occupied desktops
- Show the date, time, volume, CPU statistics, and other information
- Show the current playing song or anything else you want

You should not use polybar if:

- You already use a desktop environment that has an information panel

[polybar]: https://github.com/jaagr/polybar
