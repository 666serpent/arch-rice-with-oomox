# tmux

[tmux][tmux] is a terminal multiplexer.

## Use Cases

tmux can be used to:

- Have persistent history in the terminal
- Detach sessions and re-attach them later
- Work with multiple shells while SSH'd in another machine

You should not use tmux if:

- You should use tmux.

[tmux]: https://github.com/tmux/tmux
